package com.fatec.ads;

import java.util.ArrayList;
import java.util.List;

public class Consulta extends Agenda {

    private String motivo;
    private String historico;
    private List<Exame> exames = new ArrayList<>();
    private List<Receita> receitas = new ArrayList<>();

    public List<Exame> getExames() {
        return exames;
    }

    public void setExames(List<Exame> exames) {
        this.exames = exames;
    }

    public List<Receita> getReceitas() {
        return receitas;
    }

    public void setReceitas(List<Receita> receitas) {
        this.receitas = receitas;
    }

    public void marcar() {
        System.out.println("Consulta marcada para " + data + " às " + hora);
    }

    public void cancelar() {
        System.out.println("Consulta cancelada do paciente " + paciente.getNome());
    }

    public void realizar() {
        System.out.println("Consulta realizada pelo médico " + medico.getNome());
    }

    public void atualizar() {
        System.out.println("Consulta atualizada.");
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) throws Exception {
        if (motivo == null || motivo.length() <= 0)
            throw new Exception("Motivo da consulta e obrigatorio !!");
        this.motivo = motivo;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public Consulta(String hora, String data, Medico medico, Paciente paciente, String motivo, String historico, List<Receita> r, List<Exame> e) {
        this.hora = hora;
        this.data = data;
        this.medico = medico;
        this.paciente = paciente;
        this.motivo = motivo;
        this.historico = historico;
        this.receitas = r;
        this.exames = e;
    }

    public Consulta() {
    }

    public void mostrar() {
        System.out.println("=== Consulta ===");
        System.out.println("Paciente: " + paciente.getNome());
        System.out.println("Médico: " + medico.getNome());
        System.out.println("Data: " + data + " Hora: " + hora);
        System.out.println("Motivo: " + motivo);
        System.out.println("Histórico: " + historico);

        System.out.println("--- Exames solicitados ---");
        for (Exame exame : exames) {
            exame.mostrar();
        }

        System.out.println("--- Receitas ---");
        for (Receita receita : receitas) {
            receita.mostrar();
        }
    }
}
