package com.fatec.ads;

public class Exame extends Prodecimento {

    public void solicitar() {
        System.out.println("Exame solicitado: " + descritivo);
    }

    @Override
    public void consultar() {
        System.out.println("Consultando exame realizado em " + data);
    }

    public Exame(String data, String descritivo) {
        this.data = data;
        this.descritivo = descritivo;
    }

    public Exame() {
    }

    @Override
    public void mostrar() {
        System.out.println("Exame -> Data: " + data + " | Descrição: " + descritivo);
    }
}
