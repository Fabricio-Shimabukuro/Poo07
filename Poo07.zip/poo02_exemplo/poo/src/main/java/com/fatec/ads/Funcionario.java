package com.fatec.ads;

public abstract class Funcionario {

    protected String telefone;
    protected String senha;
    protected String nome;

    public abstract void acessar();
    public abstract void mostrar();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
