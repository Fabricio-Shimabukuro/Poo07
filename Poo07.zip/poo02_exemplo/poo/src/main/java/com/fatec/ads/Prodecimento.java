package com.fatec.ads;

public abstract class Prodecimento {

    protected String data;
    protected String descritivo;

    public abstract void mostrar();
    public abstract void consultar();

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDescritivo() {
        return descritivo;
    }

    public void setDescritivo(String descritivo) throws Exception {
        if (descritivo == null || descritivo.length() <= 0)
            throw new Exception("Informe o descritivo do procedimento");

        this.descritivo = descritivo;
    }
}
