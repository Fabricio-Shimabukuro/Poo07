package com.fatec.ads;

public class Receita extends Prodecimento {

    public Receita(String data, String descritivo) {
        this.data = data;
        this.descritivo = descritivo;
    }

    public void prescrever() {
        System.out.println("Receita prescrita: " + descritivo);
    }

    @Override
    public void consultar() {
        System.out.println("Consultando receita emitida em " + data);
    }

    @Override
    public void mostrar() {
        System.out.println("Receita -> Data: " + data + " | Medicamento: " + descritivo);
    }

    public Receita() {
    }
}
