package com.fatec.ads;

public class Recepcionista extends Funcionario {

    private String cpf;

    @Override
    public void acessar() {
        System.out.println("Recepcionista " + nome + " acessou o sistema de agendamentos.");
    }

    @Override
    public void mostrar() {
        System.out.println("Recepcionista: " + nome);
        System.out.println("CPF: " + cpf);
        System.out.println("Telefone: " + telefone);
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Recepcionista(String nome, String cpf, String telefone, String senha) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.senha = senha;
    }

    public Recepcionista() {
    }

    public Agenda marcarAgenda() throws Exception {
        acessar();

        Paciente p1 = new Paciente();
        p1.setCodigo(1);
        p1.setEmail("jose@norton.net.br");
        p1.setNome("Jose da Silva");

        Medico m1 = new Medico();
        m1.setCrm("234234234");
        m1.setEspecialidade("Geriatra");
        m1.setNome("Maria Antonieta");
        m1.setTelefone("2344-2344");

        Agenda a1 = new Agenda();
        a1.setData("01/04/2026");
        a1.setHora("10:20");
        a1.setMedico(m1);
        a1.setPaciente(p1);

        System.out.println("Consulta agendada para " + p1.getNome() + " com o médico " + m1.getNome());
        return a1;
    }
}
